import axios from "axios";

const API_BASE = process.env.REACT_APP_API_URL || "/api";

const api = axios.create({
  baseURL: API_BASE,
  timeout: 30000
});

// Attach token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("fmac_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle 401 globally
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem("fmac_token");
      localStorage.removeItem("fmac_user");
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

export default api;
