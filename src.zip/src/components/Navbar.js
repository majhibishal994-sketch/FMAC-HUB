import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import toast from "react-hot-toast";
import "./Navbar.css";

export default function Navbar() {
  const { user, isAdmin, logout } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setMenuOpen(false), [location]);

  const handleLogout = () => {
    logout();
    toast.success("Logged out 👋");
    navigate("/");
  };

  return (
    <nav className={`navbar ${scrolled ? "scrolled" : ""}`}>
      <div className="navbar-inner">
        <Link to="/" className="navbar-logo">
          <span className="logo-mark">⚡</span>
          <span className="logo-text">FMAC <span className="logo-hub">Hub</span></span>
        </Link>

        <div className={`navbar-links ${menuOpen ? "open" : ""}`}>
          <NavLink to="/" label="Home" current={location.pathname} />
          <NavLink to="/events" label="Events" current={location.pathname} />
          <NavLink to="/notices" label="Notices" current={location.pathname} />
          {isAdmin && <NavLink to="/admin" label="Dashboard" current={location.pathname} isAdmin />}

          <div className="navbar-actions">
            {user ? (
              <div className="user-menu">
                <span className="user-name">👤 {user.name.split(" ")[0]}</span>
                <button className="btn btn-ghost btn-sm" onClick={handleLogout}>
                  Logout
                </button>
              </div>
            ) : (
              <Link to="/login" className="btn btn-primary btn-sm">
                Admin Login
              </Link>
            )}
          </div>
        </div>

        <button
          className={`hamburger ${menuOpen ? "active" : ""}`}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <span /><span /><span />
        </button>
      </div>
    </nav>
  );
}

function NavLink({ to, label, current, isAdmin }) {
  const active = current === to || (to !== "/" && current.startsWith(to));
  return (
    <Link
      to={to}
      className={`nav-link ${active ? "active" : ""} ${isAdmin ? "admin-link" : ""}`}
    >
      {label}
    </Link>
  );
}
