import React, { useState, useEffect } from "react";
import api from "../utils/api";
import { format } from "date-fns";
import "./Notices.css";

const CATEGORIES = ["all", "exam", "admission", "result", "holiday", "general", "scholarship", "other"];

export default function Notices() {
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState("all");
  const [total, setTotal] = useState(0);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams({ limit: 50 });
    if (category !== "all") params.set("category", category);

    api.get(`/notices?${params}`)
      .then(res => {
        setNotices(res.data.notices || []);
        setTotal(res.data.total || 0);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [category]);

  const handleOpenPdf = (notice) => {
    if (notice.pdfFile) {
      const link = document.createElement("a");
      link.href = notice.pdfFile;
      link.target = "_blank";
      link.download = notice.pdfFileName || "notice.pdf";
      link.click();
    }
  };

  return (
    <div className="notices-page page-wrapper">
      <div className="container">
        <div className="notices-header">
          <div>
            <h1 className="notices-title">Notices 📋</h1>
            <p className="notices-sub">Official announcements & circulars from FMAC</p>
          </div>
          {total > 0 && (
            <span className="events-count">{total} notice{total !== 1 ? "s" : ""}</span>
          )}
        </div>

        {/* Category Filter */}
        <div className="notices-filters">
          <div className="filter-chips">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                className={`filter-chip ${category === cat ? "active" : ""}`}
                onClick={() => setCategory(cat)}
              >
                {cat === "all" ? "All" : cat.charAt(0).toUpperCase() + cat.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="notices-loading-list">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="notice-skeleton-full" />
            ))}
          </div>
        ) : notices.length === 0 ? (
          <div className="empty-state">
            <div className="emoji">📭</div>
            <h3>No notices here</h3>
            <p>Nothing posted in this category yet.</p>
          </div>
        ) : (
          <div className="notices-list-full">
            {/* Important notices first */}
            {notices.filter(n => n.isImportant).length > 0 && (
              <>
                <div className="notices-section-label">🔴 Important</div>
                {notices.filter(n => n.isImportant).map((notice, i) => (
                  <NoticeCard
                    key={notice._id}
                    notice={notice}
                    onClick={() => handleOpenPdf(notice)}
                    delay={i * 0.06}
                  />
                ))}
                <div className="notices-section-label">All Notices</div>
              </>
            )}
            {notices.filter(n => !n.isImportant).map((notice, i) => (
              <NoticeCard
                key={notice._id}
                notice={notice}
                onClick={() => handleOpenPdf(notice)}
                delay={i * 0.05}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function NoticeCard({ notice, onClick, delay }) {
  return (
    <div
      className={`notice-card animate-in ${notice.isImportant ? "important" : ""}`}
      style={{ animationDelay: `${delay}s` }}
      onClick={onClick}
    >
      <div className="notice-card-left">
        <div className="notice-pdf-icon">
          <span>PDF</span>
        </div>
      </div>

      <div className="notice-card-middle">
        <div className="notice-card-header">
          <h3 className="notice-card-title">{notice.title}</h3>
          <div className="notice-card-badges">
            {notice.isImportant && (
              <span className="notice-important">🔴 Important</span>
            )}
            <span className={`tag tag-${notice.category}`}>{notice.category}</span>
          </div>
        </div>

        {notice.description && (
          <p className="notice-card-desc">{notice.description}</p>
        )}

        <div className="notice-card-meta">
          <span className="notice-card-date">📅 {format(new Date(notice.createdAt), "MMM d, yyyy")}</span>
          {notice.pdfFileName && (
            <span className="notice-card-filename">📎 {notice.pdfFileName}</span>
          )}
          {notice.createdBy?.name && (
            <span className="notice-card-by">Posted by {notice.createdBy.name}</span>
          )}
        </div>
      </div>

      <div className="notice-card-action">
        <div className="notice-download-btn">
          <span>↓</span>
          <span>Open PDF</span>
        </div>
      </div>
    </div>
  );
}
