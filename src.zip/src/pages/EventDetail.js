import React, { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import api from "../utils/api";
import { format } from "date-fns";
import { useAuth } from "../context/AuthContext";
import toast from "react-hot-toast";
import "./EventDetail.css";

export default function EventDetail() {
  const { id } = useParams();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [volunteering, setVolunteering] = useState(false);
  const { isAdmin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    api.get(`/events/${id}`)
      .then(res => setEvent(res.data))
      .catch(() => toast.error("Event not found"))
      .finally(() => setLoading(false));
  }, [id]);

  const handleVolunteer = async () => {
    setVolunteering(true);
    try {
      const res = await api.post(`/events/${id}/volunteer`);
      const { email, subject, body } = res.data;
      const mailtoLink = `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      window.open(mailtoLink, "_blank");
      toast.success("Opening your email app! ✉️");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to open email");
    } finally {
      setVolunteering(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("Delete this event?")) return;
    try {
      await api.delete(`/events/${id}`);
      toast.success("Event deleted");
      navigate("/events");
    } catch (err) {
      toast.error("Failed to delete");
    }
  };

  if (loading) return (
    <div className="page-wrapper">
      <div className="container">
        <div className="event-detail-skeleton" />
      </div>
    </div>
  );

  if (!event) return (
    <div className="page-wrapper">
      <div className="container">
        <div className="empty-state">
          <div className="emoji">🔭</div>
          <h3>Event not found</h3>
          <Link to="/events" className="btn btn-primary" style={{ marginTop: 16 }}>← Back to Events</Link>
        </div>
      </div>
    </div>
  );

  const isPast = new Date(event.date) < new Date();
  const categoryEmoji = {
    cultural: "🎭", technical: "💻", sports: "🏆",
    academic: "📚", social: "🤝", workshop: "🔧", other: "🎉"
  };

  return (
    <div className="event-detail page-wrapper">
      <div className="container">
        {/* Breadcrumb */}
        <div className="breadcrumb">
          <Link to="/events">Events</Link>
          <span>›</span>
          <span>{event.title}</span>
        </div>

        <div className="event-detail-layout">
          {/* Main */}
          <div className="event-detail-main">
            {/* Banner */}
            <div className="event-detail-banner">
              {event.banner ? (
                <img src={event.banner} alt={event.title} />
              ) : (
                <div className="event-detail-banner-placeholder">
                  <span>{categoryEmoji[event.category] || "🎉"}</span>
                </div>
              )}
              {isPast && <div className="event-ended-overlay">Event Ended</div>}
            </div>

            {/* Content */}
            <div className="event-detail-content">
              <div className="event-detail-tags">
                <span className={`tag tag-${event.category}`}>{event.category}</span>
                {event.volunteeringOpen && !isPast && (
                  <span className="volunteer-badge">🙋 Volunteering Open</span>
                )}
                {isPast && <span className="tag tag-other">Past Event</span>}
              </div>

              <h1 className="event-detail-title">{event.title}</h1>

              {event.tags?.length > 0 && (
                <div className="event-detail-keywords">
                  {event.tags.map(tag => (
                    <span key={tag} className="keyword-chip">#{tag}</span>
                  ))}
                </div>
              )}

              <div className="event-detail-desc">
                {event.description.split("\n").map((para, i) => (
                  <p key={i}>{para}</p>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="event-detail-sidebar">
            {/* Info card */}
            <div className="event-info-card card">
              <div className="card-body">
                <h3 className="info-card-title">Event Info</h3>

                <div className="info-list">
                  <div className="info-item">
                    <span className="info-icon">📅</span>
                    <div>
                      <span className="info-label">Date</span>
                      <span className="info-value">{format(new Date(event.date), "EEEE, MMMM d, yyyy")}</span>
                    </div>
                  </div>

                  {event.endDate && (
                    <div className="info-item">
                      <span className="info-icon">📅</span>
                      <div>
                        <span className="info-label">End Date</span>
                        <span className="info-value">{format(new Date(event.endDate), "MMMM d, yyyy")}</span>
                      </div>
                    </div>
                  )}

                  {event.time && (
                    <div className="info-item">
                      <span className="info-icon">⏰</span>
                      <div>
                        <span className="info-label">Time</span>
                        <span className="info-value">{event.time}</span>
                      </div>
                    </div>
                  )}

                  {event.venue && (
                    <div className="info-item">
                      <span className="info-icon">📍</span>
                      <div>
                        <span className="info-label">Venue</span>
                        <span className="info-value">{event.venue}</span>
                      </div>
                    </div>
                  )}

                  <div className="info-item">
                    <span className="info-icon">👤</span>
                    <div>
                      <span className="info-label">Incharge</span>
                      <span className="info-value">{event.inchargeName}</span>
                    </div>
                  </div>

                  <div className="info-item">
                    <span className="info-icon">✉️</span>
                    <div>
                      <span className="info-label">Contact</span>
                      <a href={`mailto:${event.inchargeEmail}`} className="info-link">
                        {event.inchargeEmail}
                      </a>
                    </div>
                  </div>
                </div>

                {/* Volunteer Button */}
                {event.volunteeringOpen && !isPast ? (
                  <button
                    className="btn btn-primary volunteer-btn"
                    onClick={handleVolunteer}
                    disabled={volunteering}
                  >
                    {volunteering ? "Opening..." : "🙋 Apply to Volunteer"}
                  </button>
                ) : isPast ? (
                  <div className="closed-notice">This event has ended.</div>
                ) : (
                  <div className="closed-notice">Volunteering closed for this event.</div>
                )}
              </div>
            </div>

            {/* Admin controls */}
            {isAdmin && (
              <div className="admin-controls card">
                <div className="card-body">
                  <h3 className="info-card-title">Admin</h3>
                  <button className="btn btn-danger" onClick={handleDelete} style={{ width: "100%" }}>
                    🗑️ Delete Event
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
