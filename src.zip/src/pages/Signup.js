import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import toast from "react-hot-toast";
import "./Auth.css";

export default function Signup() {
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "" });
  const [idCard, setIdCard] = useState(null);
  const [idCardPreview, setIdCardPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [done, setDone] = useState(false);
  const { signup } = useAuth();

  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleIdCard = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) return toast.error("File too large (max 5MB)");

    const reader = new FileReader();
    reader.onload = (ev) => {
      setIdCard(ev.target.result);
      setIdCardPreview(ev.target.result);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.password || !form.confirmPassword) {
      return toast.error("Fill in all fields");
    }
    if (form.password !== form.confirmPassword) {
      return toast.error("Passwords don't match");
    }
    if (form.password.length < 8) {
      return toast.error("Password must be at least 8 characters");
    }
    if (!idCard) {
      return toast.error("Upload your college ID card for verification");
    }

    setLoading(true);
    try {
      await signup(form.name, form.email, form.password, idCard);
      setDone(true);
      toast.success("Request submitted! 🎉");
    } catch (err) {
      toast.error(err.response?.data?.message || "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  if (done) {
    return (
      <div className="auth-page page-wrapper">
        <div className="auth-container">
          <div className="auth-card">
            <div className="auth-header">
              <span style={{ fontSize: 48 }}>🎉</span>
              <h1 className="auth-title">Request Submitted!</h1>
              <p className="auth-sub">
                Your admin request has been sent for verification. A current admin will review your college ID and approve your account. You'll be notified once approved!
              </p>
            </div>
            <Link to="/" className="btn btn-primary" style={{ width: "100%", justifyContent: "center" }}>
              Back to Home →
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="auth-page page-wrapper">
      <div className="auth-orb orb-1" />
      <div className="auth-orb orb-2" />

      <div className="auth-container">
        <div className="auth-card">
          <div className="auth-header">
            <span className="auth-logo">⚡</span>
            <h1 className="auth-title">Apply for Admin</h1>
            <p className="auth-sub">
              Upload your college ID for verification. A current admin will review your request.
            </p>
          </div>

          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                type="text"
                name="name"
                className="form-input"
                placeholder="Your full name"
                value={form.name}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label className="form-label">College Email</label>
              <input
                type="email"
                name="email"
                className="form-input"
                placeholder="your@email.com"
                value={form.email}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Password</label>
              <div className="input-with-toggle">
                <input
                  type={showPass ? "text" : "password"}
                  name="password"
                  className="form-input"
                  placeholder="Min 8 characters"
                  value={form.password}
                  onChange={handleChange}
                />
                <button type="button" className="toggle-pass" onClick={() => setShowPass(!showPass)}>
                  {showPass ? "🙈" : "👁️"}
                </button>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Confirm Password</label>
              <input
                type="password"
                name="confirmPassword"
                className="form-input"
                placeholder="Re-enter password"
                value={form.confirmPassword}
                onChange={handleChange}
              />
            </div>

            {/* ID Card Upload */}
            <div className="form-group">
              <label className="form-label">College ID Card <span style={{color:"#ff6b6b"}}>*</span></label>
              <div className="upload-area" onClick={() => document.getElementById("id-upload").click()}>
                {idCardPreview ? (
                  <div className="upload-preview">
                    <img src={idCardPreview} alt="ID Card Preview" />
                    <span className="upload-change">Click to change</span>
                  </div>
                ) : (
                  <div className="upload-placeholder">
                    <span className="upload-icon">🪪</span>
                    <span className="upload-text">Click to upload your college ID card</span>
                    <span className="upload-hint">JPG, PNG or PDF · Max 5MB</span>
                  </div>
                )}
              </div>
              <input
                id="id-upload"
                type="file"
                accept="image/*,.pdf"
                style={{ display: "none" }}
                onChange={handleIdCard}
              />
            </div>

            <div className="auth-notice">
              <span>ℹ️</span>
              Your request will be reviewed by a current admin before you get access. This may take some time.
            </div>

            <button
              type="submit"
              className="btn btn-primary auth-submit"
              disabled={loading}
            >
              {loading ? "Submitting..." : "Submit Request →"}
            </button>
          </form>

          <div className="auth-footer">
            <p>Already an admin?</p>
            <Link to="/login" className="auth-link">Sign in →</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
