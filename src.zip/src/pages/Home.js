import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../utils/api";
import { format } from "date-fns";
import "./Home.css";

export default function Home() {
  const [events, setEvents] = useState([]);
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get("/events?limit=6"),
      api.get("/notices?limit=5")
    ]).then(([evRes, notRes]) => {
      setEvents(evRes.data.events || []);
      setNotices(notRes.data.notices || []);
    }).catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="home page-wrapper">
      {/* Hero */}
      <section className="hero">
        <div className="hero-bg">
          <div className="hero-orb orb-1" />
          <div className="hero-orb orb-2" />
          <div className="hero-orb orb-3" />
        </div>
        <div className="container hero-content">
          <div className="hero-badge">
            <span className="badge-dot" />
            Fakir Mohan Autonomous College
          </div>
          <h1 className="hero-title">
            Your college.<br />
            <span className="hero-accent">Your vibe.</span>
          </h1>
          <p className="hero-sub">
            Stay locked in with campus events, notices, and everything happening at FMAC, Baleshwar. No cap. 🔥
          </p>
          <div className="hero-ctas">
            <Link to="/events" className="btn btn-primary btn-lg">
              Browse Events →
            </Link>
            <Link to="/notices" className="btn btn-secondary btn-lg">
              View Notices
            </Link>
          </div>

          <div className="hero-stats">
            <div className="stat">
              <span className="stat-label">College</span>
              <span className="stat-value">FM Autonomous</span>
            </div>
            <div className="stat-divider" />
            <div className="stat">
              <span className="stat-label">Location</span>
              <span className="stat-value">Baleshwar, Odisha</span>
            </div>
            <div className="stat-divider" />
            <div className="stat">
              <span className="stat-label">Status</span>
              <span className="stat-value live">● Live</span>
            </div>
          </div>
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="home-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Upcoming Events 🎯</h2>
            <Link to="/events" className="btn btn-ghost btn-sm">See all →</Link>
          </div>

          {loading ? (
            <div className="home-loading">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="event-card-skeleton" />
              ))}
            </div>
          ) : events.length === 0 ? (
            <div className="empty-state">
              <div className="emoji">🗓️</div>
              <h3>No events yet</h3>
              <p>Check back later for upcoming events!</p>
            </div>
          ) : (
            <div className="events-grid">
              {events.map((event, i) => (
                <EventCard key={event._id} event={event} delay={i * 0.1} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Notices */}
      <section className="home-section home-notices-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Latest Notices 📋</h2>
            <Link to="/notices" className="btn btn-ghost btn-sm">See all →</Link>
          </div>

          {loading ? (
            <div className="notices-loading">
              {[...Array(3)].map((_, i) => <div key={i} className="notice-skeleton" />)}
            </div>
          ) : notices.length === 0 ? (
            <div className="empty-state">
              <div className="emoji">📭</div>
              <h3>No notices yet</h3>
              <p>Nothing posted yet.</p>
            </div>
          ) : (
            <div className="notices-list-home">
              {notices.map((notice, i) => (
                <NoticeRow key={notice._id} notice={notice} delay={i * 0.08} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="footer-inner">
            <div className="footer-brand">
              <span className="logo-mark">⚡</span>
              <span className="logo-text">FMAC <span className="logo-hub">Hub</span></span>
            </div>
            <p className="footer-note">
              Made with ❤️ for FM Autonomous College students · Baleshwar, Odisha
            </p>
            <p className="footer-disclaimer">Not an official college website.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function EventCard({ event, delay }) {
  const categoryColors = {
    cultural: "#ff6ab0", technical: "#6afff5", sports: "#ffd86a",
    academic: "#7c6aff", social: "#7fff7f", workshop: "#ffa050", other: "#a0a0c0"
  };

  const isPast = new Date(event.date) < new Date();

  return (
    <Link
      to={`/events/${event._id}`}
      className="event-card card"
      style={{ animationDelay: `${delay}s` }}
    >
      {event.banner ? (
        <div className="event-card-banner">
          <img src={event.banner} alt={event.title} />
          {isPast && <div className="past-overlay">Ended</div>}
        </div>
      ) : (
        <div className="event-card-banner-placeholder" style={{ background: `linear-gradient(135deg, ${categoryColors[event.category] || "#7c6aff"}22, ${categoryColors[event.category] || "#7c6aff"}08)` }}>
          <span className="banner-emoji">
            {event.category === "cultural" ? "🎭" : event.category === "technical" ? "💻" : event.category === "sports" ? "🏆" : event.category === "academic" ? "📚" : event.category === "workshop" ? "🔧" : "🎉"}
          </span>
          {isPast && <div className="past-overlay">Ended</div>}
        </div>
      )}

      <div className="event-card-body">
        <div className="event-card-meta">
          <span className={`tag tag-${event.category}`}>{event.category}</span>
          {event.volunteeringOpen && !isPast && (
            <span className="volunteer-badge">🙋 Volunteer</span>
          )}
        </div>

        <h3 className="event-card-title">{event.title}</h3>

        <p className="event-card-desc">
          {event.shortDesc || event.description?.slice(0, 100) + "..."}
        </p>

        <div className="event-card-footer">
          <div className="event-card-date">
            📅 {format(new Date(event.date), "MMM d, yyyy")}
          </div>
          {event.venue && (
            <div className="event-card-venue">📍 {event.venue}</div>
          )}
        </div>
      </div>
    </Link>
  );
}

function NoticeRow({ notice, delay }) {
  const handleOpen = (e) => {
    e.preventDefault();
    if (notice.pdfFile) {
      const link = document.createElement("a");
      link.href = notice.pdfFile;
      link.target = "_blank";
      link.download = notice.pdfFileName || "notice.pdf";
      link.click();
    }
  };

  return (
    <div
      className="notice-row animate-in"
      style={{ animationDelay: `${delay}s` }}
      onClick={handleOpen}
    >
      <div className="notice-row-icon">📄</div>
      <div className="notice-row-content">
        <div className="notice-row-header">
          <h4 className="notice-row-title">{notice.title}</h4>
          <div className="notice-row-badges">
            {notice.isImportant && <span className="notice-important">🔴 Important</span>}
            <span className={`tag tag-${notice.category}`}>{notice.category}</span>
          </div>
        </div>
        {notice.description && (
          <p className="notice-row-desc">{notice.description}</p>
        )}
        <span className="notice-row-date">
          {format(new Date(notice.createdAt), "MMM d, yyyy")}
        </span>
      </div>
      <div className="notice-row-action">
        <span className="pdf-btn">PDF ↓</span>
      </div>
    </div>
  );
}
