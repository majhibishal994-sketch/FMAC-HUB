import React, { useState, useEffect } from "react";
import api from "../utils/api";
import { useAuth } from "../context/AuthContext";
import { format } from "date-fns";
import toast from "react-hot-toast";
import "./AdminDashboard.css";

const TABS = ["events", "notices", "pending", "admins"];

export default function AdminDashboard() {
  const { user } = useAuth();
  const [tab, setTab] = useState("events");
  const [events, setEvents] = useState([]);
  const [notices, setNotices] = useState([]);
  const [pending, setPending] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showEventModal, setShowEventModal] = useState(false);
  const [showNoticeModal, setShowNoticeModal] = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [ev, no, pe, ad] = await Promise.all([
        api.get("/events?limit=100"),
        api.get("/notices?limit=100"),
        api.get("/admin/pending"),
        api.get("/admin/admins")
      ]);
      setEvents(ev.data.events || []);
      setNotices(no.data.notices || []);
      setPending(pe.data || []);
      setAdmins(ad.data || []);
    } catch (err) {
      toast.error("Failed to load data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchAll(); }, []);

  const deleteEvent = async (id) => {
    if (!window.confirm("Delete this event?")) return;
    await api.delete(`/events/${id}`);
    toast.success("Event deleted");
    fetchAll();
  };

  const deleteNotice = async (id) => {
    if (!window.confirm("Delete this notice?")) return;
    await api.delete(`/notices/${id}`);
    toast.success("Notice deleted");
    fetchAll();
  };

  const approveAdmin = async (id) => {
    await api.post(`/admin/approve/${id}`);
    toast.success("Admin approved! 🎉");
    fetchAll();
  };

  const rejectAdmin = async (id) => {
    if (!window.confirm("Reject this request?")) return;
    await api.post(`/admin/reject/${id}`);
    toast.success("Request rejected");
    fetchAll();
  };

  const removeAdmin = async (id) => {
    if (!window.confirm("Remove this admin?")) return;
    await api.delete(`/admin/remove/${id}`);
    toast.success("Admin removed");
    fetchAll();
  };

  return (
    <div className="admin-page page-wrapper">
      <div className="container">
        {/* Header */}
        <div className="admin-header">
          <div>
            <h1 className="admin-title">Dashboard 🛠️</h1>
            <p className="admin-sub">Welcome, {user?.name}! Manage events, notices & admins.</p>
          </div>
          <div className="admin-header-actions">
            <button className="btn btn-secondary" onClick={() => setShowNoticeModal(true)}>
              + New Notice
            </button>
            <button className="btn btn-primary" onClick={() => setShowEventModal(true)}>
              + New Event
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="admin-stats">
          <StatCard icon="🎯" label="Events" value={events.length} color="accent" />
          <StatCard icon="📋" label="Notices" value={notices.length} color="pink" />
          <StatCard icon="⏳" label="Pending Requests" value={pending.length} color="yellow" />
          <StatCard icon="👥" label="Total Admins" value={admins.length} color="cyan" />
        </div>

        {/* Tabs */}
        <div className="admin-tabs">
          {TABS.map(t => (
            <button
              key={t}
              className={`admin-tab ${tab === t ? "active" : ""}`}
              onClick={() => setTab(t)}
            >
              {t === "events" && "🎯 Events"}
              {t === "notices" && "📋 Notices"}
              {t === "pending" && `⏳ Pending ${pending.length > 0 ? `(${pending.length})` : ""}`}
              {t === "admins" && "👥 Admins"}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="admin-loading">
            {[...Array(4)].map((_, i) => <div key={i} className="admin-skeleton" />)}
          </div>
        ) : (
          <div className="admin-content">
            {tab === "events" && (
              <EventsTab events={events} onDelete={deleteEvent} />
            )}
            {tab === "notices" && (
              <NoticesTab notices={notices} onDelete={deleteNotice} />
            )}
            {tab === "pending" && (
              <PendingTab pending={pending} onApprove={approveAdmin} onReject={rejectAdmin} />
            )}
            {tab === "admins" && (
              <AdminsTab admins={admins} currentUser={user} onRemove={removeAdmin} />
            )}
          </div>
        )}
      </div>

      {showEventModal && (
        <AddEventModal
          onClose={() => setShowEventModal(false)}
          onSuccess={() => { setShowEventModal(false); fetchAll(); }}
        />
      )}

      {showNoticeModal && (
        <AddNoticeModal
          onClose={() => setShowNoticeModal(false)}
          onSuccess={() => { setShowNoticeModal(false); fetchAll(); }}
        />
      )}
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  return (
    <div className={`stat-card stat-${color}`}>
      <span className="stat-card-icon">{icon}</span>
      <div>
        <div className="stat-card-value">{value}</div>
        <div className="stat-card-label">{label}</div>
      </div>
    </div>
  );
}

function EventsTab({ events, onDelete }) {
  return (
    <div className="admin-table-wrap">
      {events.length === 0 ? (
        <div className="empty-state">
          <div className="emoji">🗓️</div>
          <h3>No events yet</h3>
          <p>Click "+ New Event" to add one</p>
        </div>
      ) : (
        <table className="admin-table">
          <thead>
            <tr>
              <th>Event</th>
              <th>Category</th>
              <th>Date</th>
              <th>Venue</th>
              <th>Volunteer</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {events.map(event => (
              <tr key={event._id}>
                <td>
                  <div className="table-title">{event.title}</div>
                  <div className="table-sub">{event.inchargeName}</div>
                </td>
                <td><span className={`tag tag-${event.category}`}>{event.category}</span></td>
                <td className="table-date">{format(new Date(event.date), "MMM d, yyyy")}</td>
                <td className="table-venue">{event.venue || "—"}</td>
                <td>
                  <span className={event.volunteeringOpen ? "status-open" : "status-closed"}>
                    {event.volunteeringOpen ? "Open" : "Closed"}
                  </span>
                </td>
                <td>
                  <div className="table-actions">
                    <a href={`/events/${event._id}`} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm">View</a>
                    <button className="btn btn-danger btn-sm" onClick={() => onDelete(event._id)}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function NoticesTab({ notices, onDelete }) {
  return (
    <div className="admin-table-wrap">
      {notices.length === 0 ? (
        <div className="empty-state">
          <div className="emoji">📭</div>
          <h3>No notices yet</h3>
          <p>Click "+ New Notice" to add one</p>
        </div>
      ) : (
        <table className="admin-table">
          <thead>
            <tr>
              <th>Title</th>
              <th>Category</th>
              <th>Important</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {notices.map(notice => (
              <tr key={notice._id}>
                <td>
                  <div className="table-title">{notice.title}</div>
                  <div className="table-sub">{notice.pdfFileName}</div>
                </td>
                <td><span className={`tag tag-${notice.category}`}>{notice.category}</span></td>
                <td>
                  {notice.isImportant
                    ? <span className="notice-important">🔴 Yes</span>
                    : <span style={{ color: "var(--text3)", fontSize: 13 }}>No</span>}
                </td>
                <td className="table-date">{format(new Date(notice.createdAt), "MMM d, yyyy")}</td>
                <td>
                  <div className="table-actions">
                    <button
                      className="btn btn-ghost btn-sm"
                      onClick={() => {
                        const link = document.createElement("a");
                        link.href = notice.pdfFile;
                        link.target = "_blank";
                        link.click();
                      }}
                    >View PDF</button>
                    <button className="btn btn-danger btn-sm" onClick={() => onDelete(notice._id)}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function PendingTab({ pending, onApprove, onReject }) {
  const [viewingId, setViewingId] = useState(null);

  return (
    <div>
      {pending.length === 0 ? (
        <div className="empty-state">
          <div className="emoji">✅</div>
          <h3>All clear!</h3>
          <p>No pending admin requests</p>
        </div>
      ) : (
        <div className="pending-list">
          {pending.map(user => (
            <div key={user._id} className="pending-card card">
              <div className="pending-card-body">
                <div className="pending-info">
                  <div className="pending-avatar">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="pending-name">{user.name}</div>
                    <div className="pending-email">{user.email}</div>
                    <div className="pending-date">Applied {format(new Date(user.createdAt), "MMM d, yyyy")}</div>
                  </div>
                </div>

                {user.collegeIdCard && (
                  <button
                    className="btn btn-ghost btn-sm"
                    onClick={() => setViewingId(viewingId === user._id ? null : user._id)}
                  >
                    {viewingId === user._id ? "Hide ID" : "🪪 View ID Card"}
                  </button>
                )}

                {viewingId === user._id && user.collegeIdCard && (
                  <div className="id-card-preview">
                    <img src={user.collegeIdCard} alt="College ID Card" />
                  </div>
                )}

                <div className="pending-actions">
                  <button className="btn btn-success" onClick={() => onApprove(user._id)}>
                    ✓ Approve
                  </button>
                  <button className="btn btn-danger" onClick={() => onReject(user._id)}>
                    ✕ Reject
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function AdminsTab({ admins, currentUser, onRemove }) {
  return (
    <div className="admins-list">
      {admins.map(admin => (
        <div key={admin._id} className="admin-item card">
          <div className="admin-item-body">
            <div className="admin-item-info">
              <div className="admin-avatar">{admin.name.charAt(0).toUpperCase()}</div>
              <div>
                <div className="admin-item-name">
                  {admin.name}
                  {admin._id === currentUser?.id && <span className="you-badge">You</span>}
                </div>
                <div className="admin-item-email">{admin.email}</div>
                <div className="admin-item-date">Since {format(new Date(admin.createdAt), "MMM yyyy")}</div>
              </div>
            </div>
            {admin.email !== "umakantamajhi195@gmail.com" && admin._id !== currentUser?.id && (
              <button className="btn btn-danger btn-sm" onClick={() => onRemove(admin._id)}>
                Remove
              </button>
            )}
            {admin.email === "umakantamajhi195@gmail.com" && (
              <span className="default-badge">Default Admin</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

// ========== ADD EVENT MODAL ==========
function AddEventModal({ onClose, onSuccess }) {
  const [form, setForm] = useState({
    title: "", description: "", shortDesc: "", date: "", endDate: "",
    time: "", venue: "", category: "other", inchargeName: "",
    inchargeEmail: "", volunteeringOpen: true, volunteeringEmail: ""
  });
  const [tags, setTags] = useState([]);
  const [tagInput, setTagInput] = useState("");
  const [banner, setBanner] = useState(null);
  const [bannerPreview, setBannerPreview] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = e => {
    const val = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setForm(f => ({ ...f, [e.target.name]: val }));
  };

  const handleBanner = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) return toast.error("Image too large (max 5MB)");
    const reader = new FileReader();
    reader.onload = (ev) => { setBanner(ev.target.result); setBannerPreview(ev.target.result); };
    reader.readAsDataURL(file);
  };

  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const removeTag = (t) => setTags(tags.filter(x => x !== t));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.description || !form.date || !form.inchargeName || !form.inchargeEmail) {
      return toast.error("Fill in all required fields");
    }
    setLoading(true);
    try {
      await api.post("/events", { ...form, tags, banner });
      toast.success("Event created! 🎉");
      onSuccess();
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to create event");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal modal-lg">
        <div className="modal-header">
          <h2 className="modal-title">🎯 New Event</h2>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Event Title *</label>
              <input name="title" className="form-input" placeholder="Event name" value={form.title} onChange={handleChange} required />
            </div>

            <div className="form-group">
              <label className="form-label">Short Description</label>
              <input name="shortDesc" className="form-input" placeholder="One-liner (shown on cards)" value={form.shortDesc} onChange={handleChange} maxLength={200} />
            </div>

            <div className="form-group">
              <label className="form-label">Full Description *</label>
              <textarea name="description" className="form-input" placeholder="Describe the event in detail..." value={form.description} onChange={handleChange} rows={5} required />
            </div>

            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Start Date *</label>
                <input type="date" name="date" className="form-input" value={form.date} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label className="form-label">End Date</label>
                <input type="date" name="endDate" className="form-input" value={form.endDate} onChange={handleChange} />
              </div>
            </div>

            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Time</label>
                <input type="time" name="time" className="form-input" value={form.time} onChange={handleChange} />
              </div>
              <div className="form-group">
                <label className="form-label">Venue</label>
                <input name="venue" className="form-input" placeholder="Hall, Auditorium, etc." value={form.venue} onChange={handleChange} />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Category</label>
              <select name="category" className="form-input" value={form.category} onChange={handleChange}>
                {["cultural","technical","sports","academic","social","workshop","other"].map(c => (
                  <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Tags</label>
              <div className="chips-container">
                {tags.map(t => (
                  <span key={t} className="chip">
                    {t}
                    <button type="button" className="chip-remove" onClick={() => removeTag(t)}>✕</button>
                  </span>
                ))}
                <input
                  className="chip-input"
                  placeholder="Add tag + Enter"
                  value={tagInput}
                  onChange={e => setTagInput(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && (e.preventDefault(), addTag())}
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Banner Image</label>
              <div className="upload-area" onClick={() => document.getElementById("banner-upload").click()}>
                {bannerPreview ? (
                  <div className="upload-preview">
                    <img src={bannerPreview} alt="Banner" style={{ maxHeight: 160 }} />
                    <span className="upload-change">Click to change</span>
                  </div>
                ) : (
                  <div className="upload-placeholder">
                    <span className="upload-icon">🖼️</span>
                    <span className="upload-text">Click to upload banner (optional)</span>
                  </div>
                )}
              </div>
              <input id="banner-upload" type="file" accept="image/*" style={{ display: "none" }} onChange={handleBanner} />
            </div>

            <div className="divider" />
            <h3 className="form-section-title">Incharge & Volunteering</h3>

            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Incharge Name *</label>
                <input name="inchargeName" className="form-input" placeholder="Event coordinator name" value={form.inchargeName} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label className="form-label">Incharge Email *</label>
                <input type="email" name="inchargeEmail" className="form-input" placeholder="coordinator@email.com" value={form.inchargeEmail} onChange={handleChange} required />
              </div>
            </div>

            <div className="form-group">
              <label className="toggle-label">
                <input type="checkbox" name="volunteeringOpen" checked={form.volunteeringOpen} onChange={handleChange} />
                <span>Volunteering is Open</span>
              </label>
            </div>

            {form.volunteeringOpen && (
              <div className="form-group">
                <label className="form-label">Volunteering Email (leave blank to use incharge email)</label>
                <input type="email" name="volunteeringEmail" className="form-input" placeholder="volunteer@email.com (optional)" value={form.volunteeringEmail} onChange={handleChange} />
              </div>
            )}

            <div className="modal-form-actions">
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? "Creating..." : "Create Event 🎯"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

// ========== ADD NOTICE MODAL ==========
function AddNoticeModal({ onClose, onSuccess }) {
  const [form, setForm] = useState({
    title: "", description: "", category: "general", isImportant: false
  });
  const [pdfFile, setPdfFile] = useState(null);
  const [pdfFileName, setPdfFileName] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = e => {
    const val = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setForm(f => ({ ...f, [e.target.name]: val }));
  };

  const handlePdf = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.type !== "application/pdf") return toast.error("Only PDF files accepted");
    if (file.size > 10 * 1024 * 1024) return toast.error("PDF too large (max 10MB)");
    setPdfFileName(file.name);
    const reader = new FileReader();
    reader.onload = (ev) => setPdfFile(ev.target.result);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title) return toast.error("Enter a title");
    if (!pdfFile) return toast.error("Upload a PDF file");
    setLoading(true);
    try {
      await api.post("/notices", { ...form, pdfFile, pdfFileName });
      toast.success("Notice published! 📋");
      onSuccess();
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to create notice");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <h2 className="modal-title">📋 New Notice</h2>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Title *</label>
              <input name="title" className="form-input" placeholder="Notice title" value={form.title} onChange={handleChange} required />
            </div>

            <div className="form-group">
              <label className="form-label">Description (optional)</label>
              <textarea name="description" className="form-input" placeholder="Brief description..." value={form.description} onChange={handleChange} rows={3} />
            </div>

            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Category</label>
                <select name="category" className="form-input" value={form.category} onChange={handleChange}>
                  {["exam","admission","result","holiday","general","scholarship","other"].map(c => (
                    <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>
                  ))}
                </select>
              </div>
              <div className="form-group" style={{ justifyContent: "flex-end" }}>
                <label className="toggle-label">
                  <input type="checkbox" name="isImportant" checked={form.isImportant} onChange={handleChange} />
                  <span>Mark as Important</span>
                </label>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">PDF File *</label>
              <div
                className={`upload-area pdf-upload ${pdfFile ? "has-file" : ""}`}
                onClick={() => document.getElementById("pdf-upload").click()}
              >
                {pdfFile ? (
                  <div className="upload-placeholder">
                    <span className="upload-icon">✅</span>
                    <span className="upload-text">{pdfFileName}</span>
                    <span className="upload-hint">Click to replace</span>
                  </div>
                ) : (
                  <div className="upload-placeholder">
                    <span className="upload-icon">📄</span>
                    <span className="upload-text">Click to upload PDF notice</span>
                    <span className="upload-hint">PDF only · Max 10MB</span>
                  </div>
                )}
              </div>
              <input id="pdf-upload" type="file" accept=".pdf" style={{ display: "none" }} onChange={handlePdf} />
            </div>

            <div className="modal-form-actions">
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? "Publishing..." : "Publish Notice 📋"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
