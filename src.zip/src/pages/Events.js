import React, { useState, useEffect, useCallback } from "react";
import { Link, useSearchParams } from "react-router-dom";
import api from "../utils/api";
import { format } from "date-fns";
import "./Events.css";

const CATEGORIES = ["all", "cultural", "technical", "sports", "academic", "social", "workshop", "other"];

export default function Events() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [events, setEvents] = useState([]);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState(searchParams.get("q") || "");
  const [category, setCategory] = useState(searchParams.get("cat") || "all");
  const [startDate, setStartDate] = useState(searchParams.get("from") || "");
  const [endDate, setEndDate] = useState(searchParams.get("to") || "");
  const [page, setPage] = useState(1);

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, limit: 9 });
      if (search) params.set("search", search);
      if (category !== "all") params.set("category", category);
      if (startDate) params.set("startDate", startDate);
      if (endDate) params.set("endDate", endDate);

      const res = await api.get(`/events?${params}`);
      setEvents(res.data.events || []);
      setTotal(res.data.total || 0);
      setPages(res.data.pages || 1);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [search, category, startDate, endDate, page]);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    const sp = {};
    if (search) sp.q = search;
    if (category !== "all") sp.cat = category;
    if (startDate) sp.from = startDate;
    if (endDate) sp.to = endDate;
    setSearchParams(sp);
  };

  const clearFilters = () => {
    setSearch(""); setCategory("all"); setStartDate(""); setEndDate(""); setPage(1);
    setSearchParams({});
  };

  const hasFilters = search || category !== "all" || startDate || endDate;

  return (
    <div className="events-page page-wrapper">
      <div className="container">
        {/* Header */}
        <div className="events-header">
          <div>
            <h1 className="events-title">Events 🎯</h1>
            <p className="events-sub">Find what's popping at FMAC</p>
          </div>
          {total > 0 && (
            <span className="events-count">{total} event{total !== 1 ? "s" : ""}</span>
          )}
        </div>

        {/* Search & Filters */}
        <div className="search-box">
          <form className="search-form" onSubmit={handleSearch}>
            <div className="search-input-wrap">
              <span className="search-icon">🔍</span>
              <input
                type="text"
                className="search-input"
                placeholder="Search events, keywords, venues..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
              {search && (
                <button type="button" className="search-clear" onClick={() => setSearch("")}>✕</button>
              )}
            </div>
            <button type="submit" className="btn btn-primary">Search</button>
          </form>

          <div className="filters-row">
            {/* Category filter */}
            <div className="filter-group">
              <span className="filter-label">Category</span>
              <div className="filter-chips">
                {CATEGORIES.map(cat => (
                  <button
                    key={cat}
                    className={`filter-chip ${category === cat ? "active" : ""}`}
                    onClick={() => { setCategory(cat); setPage(1); }}
                  >
                    {cat === "all" ? "All" : cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            {/* Date range */}
            <div className="filter-group">
              <span className="filter-label">Date Range</span>
              <div className="date-range">
                <div className="date-input-wrap">
                  <span>From</span>
                  <input
                    type="date"
                    className="form-input date-input"
                    value={startDate}
                    onChange={e => { setStartDate(e.target.value); setPage(1); }}
                  />
                </div>
                <div className="date-input-wrap">
                  <span>To</span>
                  <input
                    type="date"
                    className="form-input date-input"
                    value={endDate}
                    onChange={e => { setEndDate(e.target.value); setPage(1); }}
                  />
                </div>
              </div>
            </div>

            {hasFilters && (
              <button className="btn btn-ghost btn-sm clear-filters" onClick={clearFilters}>
                ✕ Clear all
              </button>
            )}
          </div>
        </div>

        {/* Results */}
        {loading ? (
          <div className="events-grid-page">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="event-card-skeleton-page" />
            ))}
          </div>
        ) : events.length === 0 ? (
          <div className="empty-state">
            <div className="emoji">🔭</div>
            <h3>No events found</h3>
            <p>Try different keywords or adjust your filters</p>
            {hasFilters && (
              <button className="btn btn-secondary" style={{ marginTop: 16 }} onClick={clearFilters}>
                Clear filters
              </button>
            )}
          </div>
        ) : (
          <>
            <div className="events-grid-page">
              {events.map((event, i) => (
                <EventCard key={event._id} event={event} delay={i * 0.06} />
              ))}
            </div>

            {/* Pagination */}
            {pages > 1 && (
              <div className="pagination">
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                >← Prev</button>
                <span className="page-info">{page} / {pages}</span>
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => setPage(p => Math.min(pages, p + 1))}
                  disabled={page === pages}
                >Next →</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function EventCard({ event, delay }) {
  const categoryEmoji = {
    cultural: "🎭", technical: "💻", sports: "🏆",
    academic: "📚", social: "🤝", workshop: "🔧", other: "🎉"
  };

  const isPast = new Date(event.date) < new Date();

  return (
    <Link
      to={`/events/${event._id}`}
      className="event-card-full card animate-in"
      style={{ animationDelay: `${delay}s` }}
    >
      <div className={`event-card-banner-full ${event.banner ? "has-img" : ""}`}
        style={!event.banner ? { background: `linear-gradient(135deg, var(--surface2), var(--surface))` } : {}}>
        {event.banner ? (
          <img src={event.banner} alt={event.title} />
        ) : (
          <span className="event-emoji-large">{categoryEmoji[event.category] || "🎉"}</span>
        )}
        {isPast && <div className="past-badge">Ended</div>}
        <div className="event-card-cat">
          <span className={`tag tag-${event.category}`}>{event.category}</span>
        </div>
      </div>

      <div className="event-card-body-full">
        <h3 className="event-title-full">{event.title}</h3>
        <p className="event-desc-full">
          {event.shortDesc || event.description?.slice(0, 90) + "..."}
        </p>

        <div className="event-meta-list">
          <span>📅 {format(new Date(event.date), "EEE, MMM d · yyyy")}</span>
          {event.time && <span>⏰ {event.time}</span>}
          {event.venue && <span>📍 {event.venue}</span>}
        </div>

        {event.volunteeringOpen && !isPast && (
          <div className="volunteer-tag-full">🙋‍♀️ Volunteering Open</div>
        )}
      </div>
    </Link>
  );
}
